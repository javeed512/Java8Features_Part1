package com.cgi.java8;

@FunctionalInterface
public interface IDemo {
	
	public  abstract  int  getSize(String str);

}
