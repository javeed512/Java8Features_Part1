package com.cgi.java8;

public class Test {

	public static void main(String[] args) {
		
		
		MyInterface mi =    (int a,int b) -> {return a+b;};  //lambda expression

				System.out.println(mi.add(5, 5));
				
				MyInterface.hello2();  // static method from interface
				
				mi.hello();   //default method from interface
		
			// for every lambda exp functional interface is the refs type
		// lambda exp is the implementation to the functional interface
	
				
						// (String str) -> {return  str.length();};
				
	IDemo  demo =	(s1) -> s1.length();
	
		         

	
		System.out.println(demo.getSize("Javeed123"));
		
		
		
	}

}
