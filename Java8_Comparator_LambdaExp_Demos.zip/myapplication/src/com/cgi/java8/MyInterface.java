package com.cgi.java8;

@FunctionalInterface
public interface MyInterface { // functional interface

	// public static final int CODE = 1001;

	public abstract int add(int a, int b);

	default public void hello() {

			System.out.println("Hello I am default method from interface");
		
	}

	static public void hello2() {

		
		System.out.println("Hello I am static method from interface");
		
	}

}
