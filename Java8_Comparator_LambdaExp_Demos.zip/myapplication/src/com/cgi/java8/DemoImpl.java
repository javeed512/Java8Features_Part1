package com.cgi.java8;

public class DemoImpl implements MyInterface {

	@Override
	public int add(int a, int b) {

		return a + b;

	}

	public static void main(String[] args) {
		
		MyInterface  demo = new DemoImpl();
		
		int result =	demo.add(4, 5);
		
			System.out.println(result);

	}

}
