package com.cgi.demo;

import java.util.Set;
import java.util.TreeSet;

public class Demo {

	public static void main(String[] args) {


		
		
		/*
		 * Set<String> set = new TreeSet<String>();
		 * 
		 * 
		 * set.add("King"); set.add("Adam"); set.add("Denis"); set.add("Smith");
		 * set.add("Brown");
		 * 
		 * System.out.println(set);
		 */
			
		/*
		 * Set<Integer> set2 = new TreeSet<Integer>();
		 * 
		 * 
		 * set2.add(9); set2.add(3); set2.add(2); set2.add(4); set2.add(1);
		 * 
		 * System.out.println(set2);
		 */
			
			
		
		Set<StringBuffer>  set = new TreeSet<StringBuffer>(new MyComparator());
		
		
		set.add(new StringBuffer("B"));
		set.add(new StringBuffer("D"));
		set.add(new StringBuffer("A"));
		set.add(new StringBuffer("E"));
		set.add(new StringBuffer("C"));
		
		System.out.println(set);
			
			
			
		
		
	}

}
