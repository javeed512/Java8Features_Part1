package com.cgi.lambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {


		 Comparator<Employee> empNameComparator = (Employee e1,Employee e2)->{return e1.getEname().compareTo(e2.getEname());}; 
			
		
		
		TreeSet<Employee>  employees = new TreeSet<Employee>(empNameComparator);
		
		
			employees.add(new Employee(101,"king"));
			employees.add(new Employee(106,"adam"));
			employees.add(new Employee(103,"javeed"));
			employees.add(new Employee(107,"divya"));
			employees.add(new Employee(105,"abhijeet"));
			
			

			
		System.out.println(employees);
		
		for (Employee employee : employees) {
		
				System.out.println(employee);
			
		}
		
		
		List<Employee>  employees2 = new ArrayList<Employee>();
		
		employees2.add(new Employee(101,"king"));
		employees2.add(new Employee(106,"adam"));
		employees2.add(new Employee(103,"javeed"));
		employees2.add(new Employee(107,"divya"));
		employees2.add(new Employee(105,"abhijeet"));
		
		
		Collections.sort(employees2,empNameComparator);
		
		
		
			employees2.forEach((emp)->{System.out.println(emp);});
		
		
		
		
		
		
		

	}

}
